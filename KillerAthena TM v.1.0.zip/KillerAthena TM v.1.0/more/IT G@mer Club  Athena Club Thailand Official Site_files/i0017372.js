var hash="MKFnC0MMiUw7orguJUtH0g==";var turlnameindex='itwebzone.com';
var _hsv='lvs.truehits.in.th';
var _ht='goggen.php';
var _ctg='stat.php?login=itwebzone';
var _hc='i0017372';
var truehitsurl=document.URL;
document.write("<script src='http://tracker.truehits.in.th/func/th_donate_1.5.js'></script>");
document.write("<script src='http://tracker.truehits.in.th/func/th_common_1.4.js'></script>");