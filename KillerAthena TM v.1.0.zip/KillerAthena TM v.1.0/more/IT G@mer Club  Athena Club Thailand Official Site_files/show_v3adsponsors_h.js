np_ad_url = '';
np_date = new Date();
np_random = np_date.getTime();
np_org_error_handler = window.onerror;

function quoted(str) {
  return (str != null) ? '"' + str + '"' : '""';
}

function np_encodeURIComponent(str) {
  if (typeof(encodeURIComponent) == 'function') {
    return encodeURIComponent(str);
  } else {
    return escape(str);
  }
}

function np_write_tracker(tracker_event) {
  var img_url = window.np_ad_url.replace(/pagead\/ads/, 'pagead/imp.gif');
  var img_src = img_url + '&event=' + tracker_event;
  var img_tag = '<i' + 'mg height="1" width="1" border="0" ' +
                'src=' + quoted(img_src) +
                ' />';
  document.write(img_tag);
}

function np_append_url(param, value) {
  if (value) {
    window.np_ad_url += '&' + param + '=' + value;
  }
}

function np_append_url_esc(param, value) {
  if (value) {
    np_append_url(param, np_encodeURIComponent(value));
  }
}

function np_append_color(param, value) {
  if (value && typeof(value) == 'object') {
    value = value[window.np_random % value.length];
  }
  if (value) np_append_url('color_' + param, value);
}

function IntRandom(max) {
  return Math.floor(Math.random()*max);
}

var hexStr = '0123456789abcdef';
function byte2Hex(b) {
  return hexStr.charAt(Math.floor(b / 16)) + hexStr.charAt(b % 16);
}

function np_random_color(){
  return ''+byte2Hex(IntRandom(256))+byte2Hex(IntRandom(256))+byte2Hex(IntRandom(256));
}

function chkColor(c){
  var result='';
  var list='0123456789ABCDEF';
  for(var i=0;i<c.length;i++){
    for(var j=0;j<list.length;j++){
      if (list.charAt(j)==c.charAt(i).toUpperCase()){
        result+=c.charAt(i);
      }
    }
  }
  if (result.length==6) return result;
  return '';
}

ke='76745507760712731717107562960291805703';
kd='25137798444922217866294044602407940909';
function es(ke,kd,s) {
  var a = new Array();
  var sl = s.length;
  var i = 0;
  while (i < sl) {
    a[i] = s.charCodeAt(i);
    i++;
  }
  var result = "";
  var al = a.length;
  for (i = 0; i < al; i++) {
    a[i]=a[i]+ke.charCodeAt(i)+16;
    a[i]=a[i]-kd.charCodeAt(i)+16;
    result += String.fromCharCode(a[i]);
  }
  return result;
}

function np_get_user_data() {
  var javaEnabled = navigator.javaEnabled();
  var tz = -np_date.getTimezoneOffset();

  if (window.screen) {
    np_append_url("u_h", window.screen.height);
    np_append_url("u_w", window.screen.width);
    np_append_url("u_ah", window.screen.availHeight);
    np_append_url("u_aw", window.screen.availWidth);
    np_append_url("u_cd", window.screen.colorDepth);
  }

  np_append_url("u_tz", tz);
  np_append_url("u_his", history.length);
  np_append_url("u_java", javaEnabled);

  if (navigator.plugins) {
    np_append_url("u_nplug", navigator.plugins.length);
  }
  if (navigator.mimeTypes) {
    np_append_url("u_nmime", navigator.mimeTypes.length);
  }
}

function np_show_ad() {
  var w = window;
  w.onerror = w.np_org_error_handler;

  if (w.np_num_ad_slots) {
    w.np_num_ad_slots = w.np_num_ad_slots + 1;
  } else {
    w.np_num_ad_slots = 1;
  }

  if (w.np_num_slots_to_rotate) {
    w.np_prev_ad_formats = null;
    if (w.np_num_slot_to_show == null) {
      w.np_num_slot_to_show = w.np_random % w.np_num_slots_to_rotate
                                  + 1;
    }
    if (w.np_num_slot_to_show != w.np_num_ad_slots) {
      return;
    }
  } else if (w.np_num_ad_slots > 3 && w.np_ad_region == null) {
    return;
  }

  w.np_ad_url = 'http://tns.nipa.co.th/pagead/v3adsponsor_h.php?';
  w.np_ad_url += 'adType='+w.np_ad_type;
  w.np_ad_url += '&ad_amount='+w.np_ad_amount;
  w.np_ad_client = w.np_ad_client.toUpperCase();
  client = es(ke,kd,w.np_ad_client);
  w.np_ad_url += '&client=AID05110101';
  w.np_ad_url += '&dt=' + w.np_date.getTime();
  w.np_ad_url += '&cl=' + escape(client);

  np_append_url('hl', w.np_language);
  if (w.np_country) {
    np_append_url('gl', w.np_country);
  } else {
    np_append_url('gl', w.np_gl);
  }
  np_append_url('gr', w.np_region);
  np_append_url_esc('gcs', w.np_city);
  np_append_url_esc('hints', w.np_hints);
  np_append_url('adsafe', w.np_safe);
  np_append_url('oe', w.np_encoding);
  np_append_url('lmt', w.np_last_modified_time);
  //np_append_url_esc('alternate_ad_url', w.np_alternate_ad_url);
  np_append_url('alt_color', w.np_alternate_color);
  np_append_url("skip", w.np_skip);

  if (w.np_prev_ad_formats) {
    np_append_url_esc('prev_fmts', w.np_prev_ad_formats.toLowerCase());
  }

  if (w.np_ad_format) {
    np_append_url_esc('format', w.np_ad_format.toLowerCase());
    if (w.np_prev_ad_formats) {
      w.np_prev_ad_formats = w.np_prev_ad_formats + ',' + w.np_ad_format;
    } else {
      w.np_prev_ad_formats = w.np_ad_format;
    }
  }

  np_append_url('num_ads', w.np_max_num_ads);
  np_append_url('output', w.np_ad_output);
  np_append_url('adtest', w.np_adtest);
  if (w.np_ad_channel) {
    np_append_url_esc('channel', w.np_ad_channel.toLowerCase());
  }

  if (w.np_color_bg){
    w.np_color_bg = chkColor(w.np_color_bg);
    if (!w.np_color_bg) w.np_color_bg = np_random_color();
  }else{
    w.np_color_bg = np_random_color();
  }
  if (w.np_color_border){
    w.np_color_border = chkColor(w.np_color_border);
    if (!w.np_color_border) w.np_color_border = np_random_color();
  }else{
    w.np_color_border = np_random_color();
  }
  
  //np_append_url_esc('url', w.np_page_url);
  np_append_color('bg', w.np_color_bg);
  np_append_color('text', w.np_color_text);
  np_append_color('link', w.np_color_link);
  np_append_color('url', w.np_color_url);
  np_append_color('border', w.np_color_border);
  np_append_color('line', w.np_color_line);
  np_append_url('kw_type', w.np_kw_type);
  np_append_url_esc('kw', w.np_kw);
  np_append_url_esc('contents', w.np_contents);
  np_append_url('num_radlinks', w.np_num_radlinks);
  np_append_url('max_radlink_len', w.np_max_radlink_len);
  np_append_url('rl_filtering', w.np_rl_filtering);
  np_append_url('rl_mode', w.np_rl_mode);
  np_append_url('ad_type', w.np_ad_type);
  np_append_url('image_size', w.np_image_size);
  np_append_url('region', w.np_ad_region);
  np_append_url('feedback_link', w.np_feedback);

  var chk_aid='AID07050603,AID07022706,AID06061401,AID07042301,AID07070902,AID07022704,AID07040501,AID07022705,AID06060102,AID07051815,AID07051706,AID07040202,AID07062203,AID05111201,AID06033002,AID07051702,AID07031502,AID06082201,AID07042309,AID06030213,AID07040310,AID07030103,AID07051816,AID07051104,AID06102101,AID07071402,AID06092403,AID07022101,AID07052103,AID07072803,AID07010301,AID07050303,AID06100203,AID07080102,AID05111503,AID06060201,AID06101806,AID06110901,AID07041302,AID07051604,AID06070401,AID07011103,AID05111701,AID07051810,AID06071002,AID06120701,AID05122303,AID07072708,AID07051811,AID07011104,AID06112902,AID07020504,AID06050301,AID06110201,AID05110104,AID06090804,AID06011309,AID07051813,AID06120401,AID06031102,AID06070303,AID06010806,AID07050103,AID06101601,AID06021510,AID06021001,AID06012205,AID07010901,AID05122301,AID06040501,AID06082802,AID06060104,AID06080701,AID06011006,AID06071004,AID06120601,AID06052902,AID06092109,AID06040502,AID05110901,AID06022602,AID07042601,AID06031702,AID07042304,AID07030703,AID06082402,AID07011803,AID06082401,AID07030201,AID07041904,AID05111102,AID06010302,AID06111711,AID05110101,AID06042702,AID06060514,AID06101106,AID06090702,AID05112803,AID05112802,AID06110801,AID07012203,AID05121401,AID06102202,AID07020505,AID07031603,AID05110103,AID06021403,AID06081802,AID06101208,AID06101210,AID06111104,AID07030204,AID07030702,AID07040403,AID07052405,AID07052903,AID07092606';

  var regexp=eval("/"+w.np_ad_client+"/gi");
  if (chk_aid.search(regexp)>=0) {
    a='';
  }else{
    np_append_url_esc('t', w.np_ad_client.replace('AID',''));
    np_append_url_esc('ref', document.location);
    var tloc;try{tloc=window.top.location.href;}catch(err){tloc=document.referrer.toString()+'?top_loc=err';}
    np_append_url_esc('turl',tloc);
  }

  np_get_user_data();

  w.np_ad_url = w.np_ad_url.substring(0, 1000);
  w.np_ad_url = w.np_ad_url.replace(/%\w?$/, '');

  if (np_ad_output == 'js' && w.np_ad_request_done) {
    document.write('<scr' + 'ipt language="JavaScript1.1"' +
                   ' src=' + quoted(np_ad_url) +
                   '></scr' + 'ipt>');
  } else if (np_ad_output == 'html') {
    if (w.name == 'np_ads_frame') {
      np_write_tracker('reboundredirect');
    } else {
      document.write('<ifr' + 'ame' +
                     ' name="np_ads_frame"' +
                     ' width=' + quoted(w.np_ad_width) +
                     ' height=' + quoted(w.np_ad_height) +
                     ' frameborder=' + quoted(w.np_ad_frameborder) +
                     ' src=' + quoted(w.np_ad_url) +
                     ' marginwidth="0"' +
                     ' marginheight="0"' +
                     ' vspace="0"' +
                     ' hspace="0"' +
                     ' allowtransparency="true"' +
                     ' style="BORDER-BOTTOM: '+ w.np_color_border+' thin solid;"' +
                     ' scrolling="no">');
      np_write_tracker('noiframe');
      document.write('</ifr' + 'ame>');
    }
  }

  w.np_ad_frameborder = null;
  w.np_ad_format = null;
  w.np_page_url = null;
  w.np_language = null;
  w.np_gl = null;
  w.np_country = null;
  w.np_region = null;
  w.np_city = null;
  w.np_hints = null;
  w.np_safe = null;
  w.np_encoding = null;
  w.np_ad_output = null;
  w.np_max_num_ads = null;
  w.np_ad_channel = null;
  w.np_contents = null;
  w.np_alternate_ad_url = null;
  w.np_alternate_color = null;
  w.np_color_bg = null;
  w.np_color_text = null;
  w.np_color_link = null;
  w.np_color_url = null;
  w.np_color_border = null;
  w.np_color_line = null;
  w.np_adtest = null;
  w.np_kw_type = null;
  w.np_kw = null;
  w.np_num_radlinks = null;
  w.np_max_radlink_len = null;
  w.np_rl_filtering = null;
  w.np_rl_mode = null;
  w.np_ad_type = null;
  w.np_image_size = null;
  w.np_feedback = null;
  w.np_skip = null;
  w.np_page_location = null;
  w.np_referrer_url = null;
  w.np_ad_region = null;
}

function np_error_handler(message, url, line) {
  np_show_ad();
  return true;
}

window.onerror = np_error_handler;

if (window.np_ad_frameborder == null) {
  np_ad_frameborder = 0;
}

if (window.np_ad_output == null) {
  np_ad_output = 'html';
}

if (window.np_ad_format == null && window.np_ad_output == 'html') {
  np_ad_format = np_ad_width + 'x' + np_ad_height;
}

if (window.np_page_url == null) {
  np_page_url = document.referrer;
  if (window.top.location == document.location) {
    np_page_url = document.location;
    np_last_modified_time = Date.parse(document.lastModified) / 1000;
    np_referrer_url = document.referrer;
  }
} else {
  np_page_location = document.referrer;
  if (window.top.location == document.location) {
    np_page_location = document.location;
  }
}

np_show_ad();


