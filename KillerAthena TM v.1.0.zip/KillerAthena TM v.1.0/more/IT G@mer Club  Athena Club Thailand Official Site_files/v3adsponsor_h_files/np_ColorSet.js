function toColor(h) {
  return [ parseInt(h.substring(0, 2), 16),
           parseInt(h.substring(2, 4), 16),
           parseInt(h.substring(4, 6), 16) ];
}

function toHex(c) {
  var r, g, b;
  r = c[0].toString(16);
  if (c[0] < 0x10) {
    r = "0" + r;
  }
  g = c[1].toString(16);
  if (c[1] < 0x10) {
    g = "0" + g;
  }
  b = c[2].toString(16);
  if (c[2] < 0x10) {
    b = "0" + b;
  }
  return (r + g + b).toUpperCase();
}

function toSource(d, f) {
  var s = "[";
  var same = true;
  var prev = null;
  var curr;
  for (var i = 0; i < d.length; i++) {
    curr = toHex(d[i][f]);
    if (prev == null) {
      prev = curr;
    }
    if (same && (prev != curr)) {
      same = false;
    }
    s += "\"" + curr + "\",";
  }
  if (same) {
    return "\"" + curr + "\"";
  }
  return s.substring(0, s.length - 1) + "]";
}

function getTextHex(c) {
  return ((0.3*c[0] + 0.59*c[1] + 0.11*c[2]) <= 128) ? "FFFFFF" : "000000";
}

/* write color menu */
function wm(c) {
  var b = false;
  var l = false;
  for(var i = 0; i < np_colors.length; i++) {
    if (np_colors[i].custom) {
      l = true;
      break;
    }
  }
  if (l && !c) {
    document.write("<optgroup label='Custom'>");
  }
  for(var i = 0; i < np_colors.length; i++) {
    if (!np_colors[i].custom) {
      if (c) {
        continue;
      } else if (l && !b) {
        document.write("</optgroup><optgroup label='Built-in'>");
        b = true;
      }
    }
    document.write("<option>"+np_colors[i].name+"</option>");
  }
  if (l && !c) {
    document.write("</optgroup>");
  }
}


