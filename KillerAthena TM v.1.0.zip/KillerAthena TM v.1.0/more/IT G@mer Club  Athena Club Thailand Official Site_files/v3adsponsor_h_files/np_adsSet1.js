/* set color on preview ad i */
function sc(c, i) {
  if (!c) {
    document.getElementById(i+".border").style.visibility = "hidden";
    return;
  }
  document.getElementById(i+".link").style.color = "#" + toHex(c.link);
  document.getElementById(i+".url").style.color = "#" + toHex(c.url);
  document.getElementById(i+".text").style.color = "#" + toHex(c.text);
  document.getElementById(i+".bg").style.backgroundColor = "#" + toHex(c.bg);
  document.getElementById(i+".border").style.visibility = "visible";
  document.getElementById(i+".border").style.backgroundColor = "#" + toHex(c.border);
  document.getElementById(i+".bordertext").style.color = "#" + getTextHex(c.border);
}

/* user set color on preview ad i */
function usc(i, color_link, color_url, color_text, color_bg, color_border) {

  document.getElementById(i+".link").style.color = "#" + color_link;
  document.getElementById(i+".url").style.color = "#" + color_url;
  document.getElementById(i+".text").style.color = "#" + color_text;
  document.getElementById(i+".bg").style.backgroundColor = "#" + color_bg;
  document.getElementById(i+".border").style.visibility = "visible";
  document.getElementById(i+".border").style.backgroundColor = "#" + color_border;
  document.getElementById(i+".bordertext").style.color = "#" + color_bg;
}

